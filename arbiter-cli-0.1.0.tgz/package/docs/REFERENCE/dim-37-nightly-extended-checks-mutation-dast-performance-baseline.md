---
title: "N37: Nightly extended checks (mutation, DAST, performance baseline)"
doc_version: "1.0.0"
status: active
last_review: "2026-05-20"
owner: ""
canonical_id: ""
tags: ['audience/dev', 'kind/reference']
related: []
---

<!-- arbiter-generated dim=N37 hash=c930cb357e7e2e168a17f86a9ff71748672cd791a218c2aac5b993873092f00f generator=kit@1 -->
# N37: Nightly extended checks (mutation, DAST, performance baseline)

| Field | Value |
|---|---|
| TML | L3 |
| Gate | ADVISORY |
| Status | covered |
| Category | cicd |
| Invariant | `INV-76` |

## Notes

T4 nightly tier runs mutation + DAST + fuzz; heartbeat monitor keeps pipeline honest

## Per-Stack Coverage

| Stack | Kind |
|---|---|
| `java` | tool: gitleaks (via secret_scan) |
| `typescript` | tool: gitleaks (via secret_scan) |
| `python` | tool: gitleaks (via secret_scan) |
| `go` | tool: gitleaks (via secret_scan) |
| `rust` | tool: gitleaks (via secret_scan) |

