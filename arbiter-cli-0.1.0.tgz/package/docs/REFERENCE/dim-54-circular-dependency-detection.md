---
title: "N54: Circular dependency detection"
doc_version: "1.0.0"
status: active
last_review: "2026-05-20"
owner: ""
canonical_id: ""
tags: ['audience/dev', 'kind/reference']
related: []
---

<!-- arbiter-generated dim=N54 hash=47eb336fe28a260163ef2d2196e7c5e8a5d7a900fd90af4e73af45ab33c140e5 generator=kit@1 -->
# N54: Circular dependency detection

| Field | Value |
|---|---|
| TML | L1 |
| Gate | BLOCKING |
| Status | covered |
| Category | scripts_quality |
| Invariant | `INV-03` |

## Notes

madge --circular at L1 gate; post-edit hook checks after every TS/JS edit

## Per-Stack Coverage

| Stack | Kind |
|---|---|
| `java` | gap |
| `typescript` | gap |
| `python` | gap |
| `go` | gap |
| `rust` | gap |

