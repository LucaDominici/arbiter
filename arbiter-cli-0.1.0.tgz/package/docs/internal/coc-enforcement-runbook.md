# Code of Conduct Enforcement Runbook

**Maintainer-private document — not committed to the public repository.**
**Contact:** ulfwerenar@gmail.com

This runbook describes how maintainers handle Code of Conduct violations in the
Arbiter project. It follows the four-tier enforcement ladder in the
[Contributor Covenant 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct.html).

---

## Receiving a Report

1. Acknowledge receipt to the reporter within 48 hours.
2. Do **not** share the reporter's identity with anyone outside the maintainer team.
3. Open a private tracking issue (GitHub private fork, Notion, or encrypted note).
4. Collect evidence: screenshots, links, timestamps, prior warnings.

---

## Tier 1 — Correction (first-warning template)

**Trigger:** Isolated inappropriate language or unprofessional tone; no pattern.

**Action:** Private written warning from a maintainer.

**Template:**

```
Subject: Code of Conduct — Correction

Hi [username],

Thank you for participating in Arbiter. We wanted to reach out privately about
a recent interaction.

[Describe specific behaviour, link to comment/PR/issue.]

This behaviour falls outside our Code of Conduct, specifically the expectation
that community members [cite relevant standard]. We are not taking any formal
action at this time, but we wanted you to be aware.

Please review our Code of Conduct: https://github.com/LucaDominici/arbiter/blob/main/CODE_OF_CONDUCT.md

We value your contributions and hope to continue working together.

— Arbiter Maintainers
```

**Record:** Note date, violation, and response in the private tracking issue.

---

## Tier 2 — Warning (warning-with-consequences template)

**Trigger:** A single serious incident or a repeated pattern after a Tier 1 correction.

**Action:** Formal written warning with explicit interaction restrictions.

**Template:**

```
Subject: Code of Conduct — Formal Warning

Hi [username],

Following [previous correction on DATE / a recent incident on DATE], we are
issuing a formal warning under our Code of Conduct.

[Describe the behaviour and why it violates the CoC.]

Consequences for this warning:

- You must not interact with [affected parties] — directly or indirectly — for
  [period, e.g. 30 days].
- This includes comments on issues/PRs, social media, and any community channel.
- Violating these terms will result in a temporary or permanent ban.

This is a final notice before escalation. Please review:
https://github.com/LucaDominici/arbiter/blob/main/CODE_OF_CONDUCT.md

— Arbiter Maintainers
```

**Record:** Update the private tracking issue; note expiry date of the restriction.

---

## Tier 3 — Temporary Ban (temp-ban template)

**Trigger:** Serious violation, sustained inappropriate behaviour, or violation of a
Tier 2 warning.

**Action:** Temporary ban from all community spaces and interactions.

**Template:**

```
Subject: Code of Conduct — Temporary Ban

Hi [username],

After reviewing your recent conduct, we have decided to issue a temporary ban
from all Arbiter community spaces.

Reason: [Brief factual description.]

Effective: [DATE] through [DATE] ([N] days).

During this period you must not:
- Comment on issues, pull requests, or discussions in the Arbiter repository.
- Interact with community members on behalf of Arbiter in any channel.
- Represent the Arbiter project in any public forum.

At the end of this period, participation may resume if the behaviour that led
to this action has not recurred. Violation of these terms will result in a
permanent ban.

— Arbiter Maintainers
```

**Enforcement steps:**

1. Block the user from the repository for the ban duration.
2. Record ban start and end date in the private tracking issue.
3. Set a calendar reminder to review at expiry.

---

## Tier 4 — Permanent Ban (perma-ban template)

**Trigger:** Pattern of repeated violations, harassment of an individual, aggression
toward or disparagement of classes of individuals, or violation of a Tier 3 ban.

**Action:** Permanent removal from all community spaces.

**Template:**

```
Subject: Code of Conduct — Permanent Ban

Hi [username],

After careful consideration, we have decided to permanently ban you from the
Arbiter community.

Reason: [Brief factual description — pattern, specific incidents with dates.]

This decision is final. You are no longer welcome to participate in Arbiter's
issues, pull requests, discussions, or any other community space.

— Arbiter Maintainers
```

**Enforcement steps:**

1. Block the user permanently from the repository.
2. Record decision in the private tracking issue (closed as resolved).
3. If the user creates alternate accounts to circumvent the ban, report to GitHub Trust & Safety.

---

## Escalation Thread Protocol

If two or more maintainers disagree on the tier:

1. Each maintainer writes a brief case for their position (2–5 sentences).
2. Discuss in the private tracking issue; aim for consensus within 72 hours.
3. If no consensus: apply the **lower** tier by default (less punitive) and
   schedule a 30-day review.
4. If a maintainer is the subject of the report: that maintainer is recused from
   the decision entirely.

---

## Public Statement Protocol

Maintainers will **not** disclose details about individual enforcement actions
publicly.

If a ban or action is visible to community members (e.g. a blocked user raises
a public issue), the approved statement is:

```
We handle Code of Conduct matters privately to protect everyone involved.
If you have questions or concerns, please contact us at ulfwerenar@gmail.com.
```

Do not confirm, deny, or elaborate on the specific action taken.

---

## Record Retention

Private tracking records are retained for 2 years from the date of the last
action. After retention, records may be deleted unless a repeat pattern makes
long-term retention necessary.
